package com.example.a0001;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.os.Bundle;



public class RegistrationActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration2);
    }

    // Função para voltar para a tela de login ao clicar no texto "Login"
    public void signup(View view) {
        Intent intent = new Intent(this, LoginActivity2.class);
        startActivity(intent);
    }
}
