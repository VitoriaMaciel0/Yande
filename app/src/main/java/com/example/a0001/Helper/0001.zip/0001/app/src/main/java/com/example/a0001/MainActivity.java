package com.example.a0001;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
private RecyclerView.Adapter adapterPopular;
private RecyclerView recyclerViewPupolar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initRecyclerView();
    }


    @SuppressLint("WrongViewCast")
    private void initRecyclerView() {
        ArrayList<PopularDomain> itens=new ArrayList<>();
        itens.add(new PopularDomain("Produtos naturais","Desfrute de um guia de saúde e bem-estar no seu bolso com o aplicativo Naturalmente Fit.\n" +
                " Descubra uma abordagem holística para sua rotina de exercícios e alimentação com este companheiro digital que celebra o poder dos produtos naturais.","art2",15,4,20));
        itens.add(new PopularDomain("Beleza","Desfrute de um guia de saúde e bem-estar no seu bolso com o aplicativo Naturalmente Fit.\n" +
                " Descubra uma abordagem holística para sua rotina de exercícios e alimentação com este companheiro digital que celebra o poder dos produtos naturais.","beleza",1,4.5,10));
        itens.add(new PopularDomain("Comidas","Desfrute de um guia de saúde e bem-estar no seu bolso com o aplicativo Naturalmente Fit. \n" +
                "Descubra uma abordagem holística para sua rotina de exercícios e alimentação com este companheiro digital que celebra o poder dos produtos naturais.","comidas",10,4.3,50));
        itens.add(new PopularDomain("Saúde","Desfrute de um guia de saúde e bem-estar no seu bolso com o aplicativo Naturalmente Fit. \n" +
                "Descubra uma abordagem holística para sua rotina de exercícios e alimentação com este companheiro digital que celebra o poder dos produtos naturais.","saude",18,4.8,100));


        
        recyclerViewPupolar=findViewById(R.id.view);
        recyclerViewPupolar.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,false));
        
        adapterPopular=new PupolarAdapter(itens);
        recyclerViewPupolar.setAdapter(adapterPopular);
    }
}