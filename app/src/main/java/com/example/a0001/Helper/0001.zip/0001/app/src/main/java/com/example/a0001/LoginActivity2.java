package com.example.a0001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;


public class LoginActivity2 extends AppCompatActivity {

 @Override
protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_login2);

    TextView signupTextView = findViewById(R.id.signupTextView);
    Button loginButton = findViewById(R.id.loginButton);

    signupTextView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            signup(v);
        }
    });

    loginButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            // Adicione aqui o código para ir para a tela principal (MainActivity)
            Intent intent = new Intent(LoginActivity2.this, MainActivity.class);
            startActivity(intent);
        }
    });
}

    public void signup(View view) {
        // Código para ir para a tela de registro (RegisterActivity)
        Intent intent = new Intent(this, RegistrationActivity2.class);
        startActivity(intent);
    }
}